from django.apps import AppConfig


class ContactformConfig(AppConfig):
    name = 'contactform'
