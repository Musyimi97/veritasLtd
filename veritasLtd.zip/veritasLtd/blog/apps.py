from django.apps import AppConfig


class NewConfig(AppConfig):
    name = 'new'
